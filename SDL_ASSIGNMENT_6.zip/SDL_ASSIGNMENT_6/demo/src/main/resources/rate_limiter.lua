local tokenKey = KEYS[1]
local timeKey = KEYS[2]

local capacity = tonumber(ARGV[1])
local refillRate = tonumber(ARGV[2])
local currentTime = tonumber(ARGV[3])

local tokens = redis.call("GET", tokenKey)
local lastTime = redis.call("GET", timeKey)

-- First request
if not tokens then
    tokens = capacity
    lastTime = currentTime
else
    tokens = tonumber(tokens)
    lastTime = tonumber(lastTime)

    -- Calculate elapsed seconds
    local elapsed = math.floor((currentTime - lastTime) / 1000)

    -- Add refilled tokens
    if elapsed > 0 then
        tokens = math.min(
            capacity,
            tokens + (elapsed * refillRate)
        )

        lastTime = currentTime
    end
end

-- Allow request if a token is available
if tokens > 0 then

    tokens = tokens - 1

    redis.call("SET", tokenKey, tostring(tokens))
    redis.call("SET", timeKey, tostring(lastTime))

    return 1

else

    redis.call("SET", tokenKey, tostring(tokens))
    redis.call("SET", timeKey, tostring(lastTime))

    return 0
end