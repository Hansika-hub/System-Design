package com.example.demo;

import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RateLimiterService {

    private final RedisTemplate<String, String> redisTemplate;

    private final DefaultRedisScript<Long> rateLimiterScript;

    // Token Bucket configuration
    private final int bucketCapacity;
    private final double refillRate;

    public RateLimiterService(
            RedisTemplate<String, String> redisTemplate,
            @Value("${rate-limiter.capacity:5}") int bucketCapacity,
            @Value("${rate-limiter.refill-rate:1.0}") double refillRate) {

        this.redisTemplate = redisTemplate;
        this.bucketCapacity = bucketCapacity;
        this.refillRate = refillRate;

        // Load Lua script from resources
        rateLimiterScript = new DefaultRedisScript<>();

        rateLimiterScript.setLocation(
                new ClassPathResource("rate_limiter.lua")
        );

        rateLimiterScript.setResultType(Long.class);
    }

    public boolean allowRequest(String clientId) {

        // Redis keys for this client
        String tokenKey =
                "rate_limit:" + clientId + ":tokens";

        String timeKey =
                "rate_limit:" + clientId + ":time";

        // Current time in milliseconds
        long currentTime =
                System.currentTimeMillis();

        // Execute Lua script atomically in Redis
        Long result = redisTemplate.execute(
                rateLimiterScript,

                List.of(tokenKey, timeKey),

                String.valueOf(bucketCapacity),
                String.valueOf(refillRate),
                String.valueOf(currentTime)
        );

        // Lua returns 1 if request is allowed
        // Lua returns 0 if request is rejected
        return result != null && result == 1;
    }
}