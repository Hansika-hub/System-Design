package com.example.demo;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class RateLimiterController {

    private final RateLimiterService rateLimiterService;

    public RateLimiterController(
            RateLimiterService rateLimiterService) {

        this.rateLimiterService = rateLimiterService;
    }

    @GetMapping("/test")
    public ResponseEntity<String> test(
            @RequestParam(required = false) String clientId,
            jakarta.servlet.http.HttpServletRequest request) {

        String clientIdentifier = clientId;
        if (clientIdentifier == null || clientIdentifier.trim().isEmpty()) {
            clientIdentifier = request.getRemoteAddr();
            if ("0:0:0:0:0:0:0:1".equals(clientIdentifier)) {
                clientIdentifier = "127.0.0.1";
            }
        }

        boolean allowed =
                rateLimiterService.allowRequest(clientIdentifier);

        if (allowed) {

            return ResponseEntity.ok(
                    "Request allowed for client: " + clientIdentifier
            );

        } else {

            return ResponseEntity
                    .status(HttpStatus.TOO_MANY_REQUESTS)
                    .body(
                            "Too many requests. Try again later."
                    );
        }
    }
}