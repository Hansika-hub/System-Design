package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	private RateLimiterService rateLimiterService;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	@Test
	void contextLoads() {
	}

	@Test
	void testRateLimiter() {
		boolean allowed = rateLimiterService.allowRequest("test-user-123");
		assertTrue(allowed);
	}

	@Test
	void testConcurrentRequests() throws InterruptedException {
		String clientId = "concurrent-client";
		// Clear existing keys for clean test state
		redisTemplate.delete("rate_limit:" + clientId + ":tokens");
		redisTemplate.delete("rate_limit:" + clientId + ":time");

		int numThreads = 10;
		ExecutorService executor = Executors.newFixedThreadPool(numThreads);
		CountDownLatch latch = new CountDownLatch(1);
		AtomicInteger allowedCount = new AtomicInteger(0);
		AtomicInteger rejectedCount = new AtomicInteger(0);

		for (int i = 0; i < numThreads; i++) {
			executor.submit(() -> {
				try {
					latch.await(); // wait for start signal
					boolean allowed = rateLimiterService.allowRequest(clientId);
					if (allowed) {
						allowedCount.incrementAndGet();
					} else {
						rejectedCount.incrementAndGet();
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
			});
		}

		latch.countDown(); // trigger all threads simultaneously
		executor.shutdown();
		boolean terminated = executor.awaitTermination(5, TimeUnit.SECONDS);
		assertTrue(terminated);

		// With a capacity of 3, exactly 3 requests must be allowed and 7 rejected
		assertEquals(3, allowedCount.get());
		assertEquals(7, rejectedCount.get());
	}

}
