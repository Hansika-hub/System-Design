# Upgrade Plan: demo (20260818123219)

- **Generated**: 2026-08-18 12:32:19
- **HEAD Branch**: N/A (Version control not available)
- **HEAD Commit ID**: N/A (Version control not available)

> Note: This project is not a git repository. Changes will not be version-controlled during this upgrade. To preserve history, consider initializing a git repository before or after the upgrade.

## Available Tools

**JDKs**
- JDK 17.0.17: C:\Users\Harshika Sipani\.jdks\ms-17.0.17\bin (current project JDK, used by baseline step)
- JDK 21: **<TO_BE_INSTALLED>** (required by upgrade steps)
- JDK 24.0.1: D:\bin (available, not used)
- JDK 25: D:\conf\bin (available, not used)

**Build Tools**
- Maven 3.9.12: C:\apache-maven-3.9.12\bin (supports Java 21)
- Maven Wrapper: 3.6.3 (embedded in project, recommended upgrade to 3.9.12+)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

No user-specified guidelines provided. Using standard Java LTS upgrade practices.

## Options

- Working branch: appmod/java-upgrade-20260818123219
- Run tests before and after the upgrade: true

## Upgrade Goals

- **Java**: Upgrade from 17 → 21 (latest LTS)
- **Spring Boot**: Maintain at 4.1.0 (fully compatible with Java 21)

## Technology Stack

| Technology/Dependency | Current | Target | Why Incompatible |
|----------------------|---------|--------|------------------|
| Java | 17 | 21 | User requested (Java 21 LTS) |
| Spring Boot | 4.1.0 | 4.1.0 | Already supports Java 21; no upgrade needed |
| Spring Framework | 6.1.x | 6.1.x | Managed by Spring Boot 4.1.0; already Java 21 compatible |
| Maven (system) | 3.9.12 | 3.9.12+ | Already supports Java 21 |
| Maven Wrapper | 3.6.3 | 3.9.6+ | 3.6.x is EOL; upgrade recommended for Java 21 support |
| spring-boot-starter-data-redis | 4.1.0 | 4.1.0 | Compatible with Java 21 |
| spring-boot-starter-webmvc | 4.1.0 | 4.1.0 | Compatible with Java 21 |

## Derived Upgrades

- **Maven Wrapper upgrade**: 3.6.3 → 3.9.6+ (recommended for Java 21; current version is EOL)

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version property | 17 | upgrade | 21 | User requested Java 21 LTS upgrade |
| .mvn/wrapper/maven-wrapper.properties | maven.wrapper.distribution.url | 3.6.3 | upgrade | 3.9.6 | EOL version; Java 21 compatibility |

### Source Code Changes

No breaking changes expected. The project uses standard Spring Boot conventions that are compatible with Java 17→21 upgrade. All current source code is forward-compatible with Java 21.

| File | Location | Current State | Required Change | Reason |
|------|----------|----------------|-----------------|--------|
| DemoApplication.java | All code | Java 17 compatible | No changes needed | Java 21 is backward-compatible with Java 17 code |

### Configuration Changes

No configuration changes required. Spring Boot 4.1.0 automatically adapts to Java 21.

### CI/CD Changes

No CI/CD files detected in this simple project (no Dockerfile, no azure-pipelines.yml, no GitHub Actions, etc.). None needed for Java upgrade.

### Risks & Warnings

- **Maven Wrapper EOL**: Maven 3.6.3 reached end-of-life in November 2022. Upgrade to 3.9.6+ recommended for long-term support. **Mitigation**: Update maven-wrapper.properties to point to 3.9.6 or later; re-run `mvnw` to download the new version.

## Upgrade Steps

### Step 1: Setup Environment
- **Rationale**: Install Java 21 JDK required for compilation and testing with the target version
- **Changes to Make**: Install JDK 21 via `#appmod-install-jdk(sessionId, 21)`
- **Verification**: 
  - Command: `#appmod-list-jdks(sessionId, version: "21")`
  - Expected Result: Java 21 installation confirmed and accessible

### Step 2: Setup Baseline
- **Rationale**: Establish baseline test pass rate with current JDK 17 before upgrade for later validation
- **Changes to Make**: Run tests with current configuration
- **Verification**:
  - Command: `mvn clean compile test-compile && mvn clean test`
  - JDK: Java 17.0.17
  - Expected Result: All tests pass (baseline established for 100% target in final validation)

### Step 3: Upgrade Java Version in pom.xml
- **Rationale**: Update the java.version property to target Java 21 LTS
- **Changes to Make**: 
  - Update `<java.version>17</java.version>` → `<java.version>21</java.version>` in pom.xml (line 31)
- **Verification**:
  - Command: `mvn clean test-compile -q`
  - JDK: Java 21
  - Expected Result: Compilation SUCCESS (no source code changes needed due to backward compatibility)

### Step 4: Upgrade Maven Wrapper
- **Rationale**: Update deprecated Maven Wrapper to 3.9.6+ for better Java 21 support and to clear EOL warning
- **Changes to Make**:
  - Update `.mvn/wrapper/maven-wrapper.properties`: change maven.wrapper.distribution.url from Apache Maven 3.6.3 to 3.9.6
  - Run `mvnw` once to download and cache the new version
- **Verification**:
  - Command: `mvnw --version`
  - Expected Result: Maven 3.9.6 confirmed

### Step 5: Final Validation
- **Rationale**: Verify all Upgrade Success Criteria are met: Java 21 compilation successful, 100% test pass rate, all code compiles with target JDK
- **Changes to Make**: 
  - Verify: all TODOs and workarounds are resolved
  - Run full test suite with Java 21
  - Iteratively fix any remaining test failures until 100% pass rate achieved
- **Verification**:
  - Command: `mvn clean verify -q`
  - JDK: Java 21
  - Expected Result: 
    - ✅ Clean compilation with Java 21
    - ✅ 100% test pass rate (matches or exceeds baseline)
    - ✅ No warnings or deprecation errors

### Step 6: CVE Validation & Fix
- **Rationale**: Scan all direct dependencies for known CVEs and apply patches if available
- **Changes to Make**:
  - Extract direct dependencies
  - Scan with `#appmod-validate-cves-for-java(sessionId, dependencies, projectPath)`
  - Upgrade any flagged dependency versions to patched versions (within same minor line acceptable)
  - Re-scan to confirm resolution
- **Verification**:
  - Command: `mvn dependency:list -DexcludeTransitive=true`
  - Expected Result: No CVEs in direct dependencies, or all CVEs documented as unfixable with justification
