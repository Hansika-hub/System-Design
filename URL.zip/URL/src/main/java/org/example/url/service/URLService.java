package org.example.url.service;


import org.example.url.Repo.URLrepo;
import org.example.url.model.URLSh;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class URLService {
    @Autowired
    private URLrepo repo;
    public String shorten(String URL) {
        String shortCode = UUID.randomUUID().toString().substring(0, 6);
        while (repo.findBySurl(shortCode) != null) {
            shortCode = UUID.randomUUID().toString().substring(0, 6);
        }

        URLSh url = new URLSh();
        url.setUrl(URL);
        url.setSurl(shortCode);

        repo.save(url);

        return shortCode;
    }

    public String findbyurl(String shortCode) {


            URLSh url = repo.findBySurl(shortCode);

            if (url == null) {
                throw new RuntimeException("Short URL not found");
            }

            return url.getUrl();

    }

    public String shorten(String url, String alias) {

        String shortCode;
        if (alias != null && !alias.isBlank()) {
            if (repo.findBySurl(alias) != null) {
                throw new RuntimeException("Alias already exists");
            }

            shortCode = alias;

        } else {

            shortCode = UUID.randomUUID().toString().substring(0, 6);
            while (repo.findBySurl(shortCode) != null) {
                shortCode = UUID.randomUUID().toString().substring(0, 6);
            }
        }

        URLSh urlObj = new URLSh();
        urlObj.setUrl(url);
        urlObj.setSurl(shortCode);

        repo.save(urlObj);

        return shortCode;
    }
}
