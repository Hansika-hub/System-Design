package org.example.webcrawler;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    private final service crawlerService;

    public Controller(service crawlerService) {
        this.crawlerService = crawlerService;
    }

    @GetMapping("/crawler")
    public String crawler(@RequestParam String url) throws Exception {
        return crawlerService.crawler(url);
    }
}