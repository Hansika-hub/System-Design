package org.example.webcrawler;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

@Service
public class service {

    private final RedisService redisService;

    public service(RedisService redisService) {
        this.redisService = redisService;
    }

    public String crawler(String url) throws Exception {

        // Queue to store URLs waiting to be crawled
        Queue<String> urlQueue = new LinkedList<>();

        // Get the host of the seed URL
        URI seedUri = new URI(url);
        String seedHost = seedUri.getHost();

        // Add seed URL to queue
        urlQueue.add(url);

        StringBuilder result = new StringBuilder();

        // Maximum number of pages to crawl
        int maxPages = 10;

        // Number of successfully crawled pages
        int pagesCrawled = 0;

        // Start crawling
        while (!urlQueue.isEmpty() && pagesCrawled < maxPages) {

            // Take one URL from queue
            String currentUrl = urlQueue.poll();

            // Check Redis
            if (redisService.isVisited(currentUrl)) {
                result.append("Already visited: ")
                        .append(currentUrl)
                        .append("<br>");

                continue;
            }

            // Validate URL
            URI currentUri;

            try {
                currentUri = new URI(currentUrl);
            } catch (Exception e) {

                result.append("Invalid URL: ")
                        .append(currentUrl)
                        .append("<br>");

                continue;
            }

            // Check HTTP/HTTPS
            String scheme = currentUri.getScheme();

            if (!"http".equalsIgnoreCase(scheme)
                    && !"https".equalsIgnoreCase(scheme)) {

                result.append("Invalid scheme: ")
                        .append(currentUrl)
                        .append("<br>");

                continue;
            }

            // Allow only same-domain URLs
            if (!seedHost.equalsIgnoreCase(currentUri.getHost())) {

                result.append("External URL skipped: ")
                        .append(currentUrl)
                        .append("<br>");

                continue;
            }

            // Mark URL as visited in Redis
            redisService.markVisited(currentUrl);

            // Display crawled URL
            result.append("<b>Crawling: </b>")
                    .append(currentUrl)
                    .append("<br>");

            // Fetch page
            Document doc;

            try {

                doc = Jsoup.connect(currentUrl)
                        .userAgent("Mozilla/5.0")
                        .timeout(10000)
                        .get();

            } catch (Exception e) {

                result.append("Failed: ")
                        .append(currentUrl)
                        .append("<br>");

                continue;
            }

            // Successful page crawl
            pagesCrawled++;

            // Extract all links
            Elements elements = doc.select("a[href]");

            result.append("Links found: ")
                    .append(elements.size())
                    .append("<br>");

            // Process each discovered link
            for (Element element : elements) {

                String linkUrl = element.absUrl("href");

                // Ignore empty URLs
                if (linkUrl.isEmpty()) {
                    continue;
                }

                // Display discovered URL
                result.append("Discovered: ")
                        .append(linkUrl)
                        .append("<br>");

                // Check Redis
                if (redisService.isVisited(linkUrl)) {

                    result.append("Already visited: ")
                            .append(linkUrl)
                            .append("<br>");

                    continue;
                }

                try {

                    URI linkUri = new URI(linkUrl);

                    String linkScheme = linkUri.getScheme();

                    // Allow only HTTP and HTTPS
                    if (!"http".equalsIgnoreCase(linkScheme)
                            && !"https".equalsIgnoreCase(linkScheme)) {

                        continue;
                    }

                    // Allow only same-domain URLs
                    if (!seedHost.equalsIgnoreCase(linkUri.getHost())) {

                        result.append("External URL skipped: ")
                                .append(linkUrl)
                                .append("<br>");

                        continue;
                    }

                    // Add new URL to queue
                    urlQueue.add(linkUrl);

                    result.append("Added to queue: ")
                            .append(linkUrl)
                            .append("<br>");

                } catch (Exception e) {

                    result.append("Invalid URL skipped: ")
                            .append(linkUrl)
                            .append("<br>");
                }
            }

            result.append("<hr>");
        }

        // Final result
        result.append("<br>");

        result.append("<b>Total pages crawled: ")
                .append(pagesCrawled)
                .append("</b>")
                .append("<br>");

        result.append("<b>Remaining URLs in queue: ")
                .append(urlQueue.size())
                .append("</b>");

        return result.toString();
    }
}
/*
public class service {

    public String crawler(String url) throws Exception {

        Queue<String> urlQueue = new LinkedList<>();
        Set<String> visitedUrls = new HashSet<>();

        // Domain of the starting URL
        URI seedUri = new URI(url);
        String seedHost = seedUri.getHost();

        // Add seed URL
        urlQueue.add(url);

        StringBuilder result = new StringBuilder();

        int maxPages = 10;
        int pagesCrawled = 0;

        while (!urlQueue.isEmpty() && pagesCrawled < maxPages) {

            // Get URL from queue
            String currentUrl = urlQueue.poll();

            // Skip if already visited
            if (visitedUrls.contains(currentUrl)) {
                continue;
            }

            // Validate URL
            URI currentUri;

            try {
                currentUri = new URI(currentUrl);
            } catch (Exception e) {
                continue;
            }

            // Allow only HTTP and HTTPS
            String scheme = currentUri.getScheme();

            if (!"http".equalsIgnoreCase(scheme)
                    && !"https".equalsIgnoreCase(scheme)) {
                continue;
            }

            // Allow only same domain
            if (!seedHost.equalsIgnoreCase(currentUri.getHost())) {
                continue;
            }

            // Mark as visited
            visitedUrls.add(currentUrl);

            result.append("Crawling: ")
                    .append(currentUrl)
                    .append("\n");

            Document doc;

            try {

                doc = Jsoup.connect(currentUrl)
                        .userAgent("Mozilla/5.0")
                        .timeout(10000)
                        .get();

            } catch (Exception e) {

                result.append("Failed: ")
                        .append(currentUrl)
                        .append("\n");

                continue;
            }

            pagesCrawled++;

            // Extract links
            Elements elements = doc.select("a[href]");

            for (Element element : elements) {

                String linkUrl = element.absUrl("href");

                if (linkUrl.isEmpty()) {
                    continue;
                }

                result.append("Discovered: ")
                        .append(linkUrl)
                        .append("<br>");

                if (visitedUrls.contains(linkUrl)) {
                    continue;
                }

                try {

                    URI linkUri = new URI(linkUrl);

                    String linkScheme = linkUri.getScheme();

                    if (!"http".equalsIgnoreCase(linkScheme)
                            && !"https".equalsIgnoreCase(linkScheme)) {
                        continue;
                    }

                    if (!seedHost.equalsIgnoreCase(linkUri.getHost())) {
                        continue;
                    }

                    urlQueue.add(linkUrl);

                } catch (Exception e) {
                    // Invalid URL - ignore
                }
            }
        }

        result.append("\nTotal pages crawled: ")
                .append(pagesCrawled);

        return result.toString();
    }
}*/