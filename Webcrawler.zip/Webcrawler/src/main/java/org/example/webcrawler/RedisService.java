package org.example.webcrawler;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class RedisService {

    private final StringRedisTemplate redisTemplate;

    public RedisService(StringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    // Check whether URL is already visited
    public boolean isVisited(String url) {
        return Boolean.TRUE.equals(
                redisTemplate.opsForSet().isMember("visitedUrls", url)
        );
    }

    // Store URL as visited
    public void markVisited(String url) {
        redisTemplate.opsForSet().add("visitedUrls", url);
    }
}