package com.example.consistent.controller;

import com.example.consistent.model.Student;
import com.example.consistent.service.StudentService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentController {

    private final StudentService studentService;

    public StudentController(
            StudentService studentService) {

        this.studentService = studentService;
    }

    @PostMapping("/students")
    public ResponseEntity<Student> addStudent(
            @RequestBody Student student) {

        return ResponseEntity.ok(
                studentService.save(student)
        );
    }

    @GetMapping("/students")
    public ResponseEntity<List<Student>> getStudents() {

        return ResponseEntity.ok(
                studentService.findAll()
        );
    }

    @GetMapping("/students/{id}")
    public ResponseEntity<Student> getStudent(
            @PathVariable String id) {

        Student student =
                studentService.findById(id);

        if (student == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(student);
    }

    @GetMapping("/students/{id}/node")
    public ResponseEntity<String> getStudentNode(
            @PathVariable String id) {

        return ResponseEntity.ok(
                studentService.locateStudent(id)
        );
    }

    @PostMapping("/nodes")
    public ResponseEntity<String> addNode(
            @RequestParam String name,
            @RequestParam String url) {

        studentService.addNode(
                name,
                url
        );

        return ResponseEntity.ok(
                "Node added: " + name
        );
    }

    @DeleteMapping("/nodes/{name}")
    public ResponseEntity<String> removeNode(
            @PathVariable String name) {

        studentService.removeNode(name);

        return ResponseEntity.ok(
                "Node removed: " + name
        );
    }
}