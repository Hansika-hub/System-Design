package com.example.consistent.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

import org.springframework.stereotype.Component;

@Component
public class ConsistentHashRing {

    private final SortedMap<Long, String> ring = new TreeMap<>();

    private final Map<String, String> nodeUrls = new HashMap<>();

    private static final int VIRTUAL_NODES = 100;

    public void addNode(String nodeName, String nodeUrl) {

        if (nodeUrls.containsKey(nodeName)) {
            return;
        }

        nodeUrls.put(nodeName, nodeUrl);

        for (int i = 0; i < VIRTUAL_NODES; i++) {

            String virtualNode =
                    nodeName + "-VN-" + i;

            long hash = hash(virtualNode);

            ring.put(hash, nodeName);
        }

        System.out.println(
                "Added node: " + nodeName
        );
    }

    public void removeNode(String nodeName) {

        if (!nodeUrls.containsKey(nodeName)) {
            return;
        }

        for (int i = 0; i < VIRTUAL_NODES; i++) {

            String virtualNode =
                    nodeName + "-VN-" + i;

            long hash = hash(virtualNode);

            ring.remove(hash);
        }

        nodeUrls.remove(nodeName);

        System.out.println(
                "Removed node: " + nodeName
        );
    }

    public String getNode(String key) {

        if (ring.isEmpty()) {
            throw new IllegalStateException(
                    "No storage nodes available"
            );
        }

        long hash = hash(key);

        SortedMap<Long, String> tailMap =
                ring.tailMap(hash);

        Long nodeHash =
                tailMap.isEmpty()
                        ? ring.firstKey()
                        : tailMap.firstKey();

        return ring.get(nodeHash);
    }

    public String getNodeUrl(String nodeName) {

        return nodeUrls.get(nodeName);
    }

    public Set<String> getNodes() {

        return new HashSet<>(nodeUrls.keySet());
    }

    private long hash(String value) {

        try {

            MessageDigest md =
                    MessageDigest.getInstance("MD5");

            byte[] digest =
                    md.digest(
                            value.getBytes(
                                    StandardCharsets.UTF_8
                            )
                    );

            long hash = 0;

            for (int i = 0; i < 8; i++) {

                hash = (hash << 8)
                        | (digest[i] & 0xff);
            }

            return hash & Long.MAX_VALUE;

        } catch (NoSuchAlgorithmException e) {

            throw new RuntimeException(e);
        }
    }
}