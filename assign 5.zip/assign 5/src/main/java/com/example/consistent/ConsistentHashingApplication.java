package com.example.consistent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsistentHashingApplication {

    public static void main(String[] args) {
        SpringApplication.run(
                ConsistentHashingApplication.class,
                args
        );
    }
}