package com.example.consistent.service;

import com.example.consistent.model.Student;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.mongodb.client.MongoClients;

import java.util.*;

@Service
public class StudentService {

    private final ConsistentHashRing hashRing;

    private final Map<String, MongoTemplate> mongoTemplates =
            new HashMap<>();

    public StudentService(ConsistentHashRing hashRing) {
        this.hashRing = hashRing;
    }

    private MongoTemplate getTemplate(String nodeName) {

        if (mongoTemplates.containsKey(nodeName)) {
            return mongoTemplates.get(nodeName);
        }

        String url =
                hashRing.getNodeUrl(nodeName);

        MongoTemplate template =
                new MongoTemplate(
                        MongoClients.create(url),
                        "students"
                );

        mongoTemplates.put(nodeName, template);

        return template;
    }

    public void addNode(
            String nodeName,
            String nodeUrl) {

        hashRing.addNode(
                nodeName,
                nodeUrl
        );

        migrateData();
    }

    public void removeNode(String nodeName) {

        MongoTemplate oldTemplate =
                getTemplate(nodeName);

        List<Student> students =
                oldTemplate.findAll(
                        Student.class
                );

        hashRing.removeNode(nodeName);

        for (Student student : students) {

            String newNode =
                    hashRing.getNode(
                            student.getId()
                    );

            MongoTemplate newTemplate =
                    getTemplate(newNode);

            newTemplate.save(student);
        }

        oldTemplate.remove(
                new Query(),
                Student.class
        );

        MongoTemplate template =
                mongoTemplates.remove(nodeName);

        if (template != null) {
            template.getMongoDatabaseFactory()
                    .getMongoDatabase()
                    .drop();
        }

        System.out.println(
                "Data migrated after removing "
                        + nodeName
        );
    }

    private void migrateData() {

        Set<String> nodes =
                hashRing.getNodes();

        for (String node : nodes) {

            MongoTemplate template =
                    getTemplate(node);

            List<Student> students =
                    template.findAll(
                            Student.class
                    );

            for (Student student : students) {

                String correctNode =
                        hashRing.getNode(
                                student.getId()
                        );

                if (!correctNode.equals(node)) {

                    MongoTemplate destination =
                            getTemplate(
                                    correctNode
                            );

                    destination.save(student);

                    template.remove(
                            new org.springframework.data.mongodb.core.query
                                    .Query(
                                    org.springframework.data.mongodb.core.query
                                            .Criteria.where("_id")
                                            .is(student.getId())
                            ),
                            Student.class
                    );

                    System.out.println(
                            "Migrated student "
                                    + student.getId()
                                    + " from "
                                    + node
                                    + " to "
                                    + correctNode
                    );
                }
            }
        }
    }

    public Student save(Student student) {

        String node =
                hashRing.getNode(
                        student.getId()
                );

        MongoTemplate template =
                getTemplate(node);

        Student saved =
                template.save(student);

        System.out.println(
                "Student "
                        + student.getId()
                        + " stored in "
                        + node
        );

        return saved;
    }

    public Student findById(String id) {

        String node =
                hashRing.getNode(id);

        MongoTemplate template =
                getTemplate(node);

        return template.findById(
                id,
                Student.class
        );
    }

    public List<Student> findAll() {

        List<Student> result =
                new ArrayList<>();

        for (String node :
                hashRing.getNodes()) {

            MongoTemplate template =
                    getTemplate(node);

            result.addAll(
                    template.findAll(
                            Student.class
                    )
            );
        }

        return result;
    }

    public String locateStudent(String id) {

        return hashRing.getNode(id);
    }
}