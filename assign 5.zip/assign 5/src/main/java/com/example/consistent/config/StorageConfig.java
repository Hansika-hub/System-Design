package com.example.consistent.config;

import java.util.Map;

public class StorageConfig {

    public static final Map<String, String> NODES = Map.of(
    "mongo1", "mongodb://localhost:27017",
    "mongo2", "mongodb://localhost:27018",
    "mongo3", "mongodb://localhost:27019",
    "mongo4", "mongodb://localhost:27020"
);

    private StorageConfig() {
    }
}